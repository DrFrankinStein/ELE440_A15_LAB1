#ifndef TRI_BASE_H
#define	TRI_BASE_H

#include "CommonFunc.h"

Barometre TriParBase(int *Donnees,int taille, int nbreChiffre);

#endif //TRI_BASE_H