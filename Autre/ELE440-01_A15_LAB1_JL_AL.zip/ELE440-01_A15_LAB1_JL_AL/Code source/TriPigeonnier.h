#ifndef TRI_PIGEONNIER_H
#define	TRI_PIGEONNIER_H

#include "CommonFunc.h"

Barometre TriPigeonnier(int *iTableau, int DataCount, int iRang);

#endif //TRI_PIGEONNIER_H