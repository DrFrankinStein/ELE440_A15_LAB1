#ifndef TRI_FUSION_H
#define	TRI_FUSION_H

#include "CommonFunc.h"

Barometre TriParFusion(int *Donnees, int indexPremier, int indexDernier);

#endif //TRI_FUSION_H