#ifndef TRI_RAPIDE_H
#define	TRI_RAPIDE_H

#include "CommonFunc.h"

Barometre TriRapide(int* Donnees, int indexPremier, int indexDernier);

#endif //TRI_RAPIDE_H