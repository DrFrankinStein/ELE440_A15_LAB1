#ifndef TRI_TAS_H
#define	TRI_TAS_H

#include <stdbool.h>
#include "CommonFunc.h"

Barometre TriParTas(int *T, int N);

#endif //TRI_TAS_H