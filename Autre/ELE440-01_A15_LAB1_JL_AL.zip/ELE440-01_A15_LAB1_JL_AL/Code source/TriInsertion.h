#ifndef TRI_INSERT_H
#define	TRI_INSERT_H

#include "CommonFunc.h"

Barometre TriParInsertion(int *Donnees,int taille);

#endif //TRI_INSERT_H